# Whole-Book Validation Checklist

## Thesis
- [ ] Central conversion problem explicit.
- [ ] Core chain visible across six parts.
- [ ] Intellectual center remains in interfaces/arrows.
- [ ] Conclusion follows from prior chapters.

## Scope
- [ ] Not general history of civilization.
- [ ] Not kOA manual.
- [ ] Not general AI book.
- [ ] Does not imply all social problems are coordination problems.

## Coherence
- [ ] Not consensus.
- [ ] Not confused with either centralization or decentralization as a topology.
- [ ] Functional centrality is distinguished from domination, sovereignty and terminal dependency.
- [ ] Not maximum connectivity.
- [ ] Not homogeneity.
- [ ] Not goodness.
- [ ] Local/global coherence distinct.
- [ ] Legible coherence not treated as proof of structural coherence.

## Power
- [ ] Coordination recognized as power-producing.
- [ ] Transparency not sufficient accountability.
- [ ] Verification, contestation, substitution, exit distinct.
- [ ] Capture not claimed impossible.
- [ ] Sanctions target demonstrated procedural violations, not moral worth.

## Expertise
- [ ] Competence contextual.
- [ ] Status/credentials treated as evidence/proxies.
- [ ] Expertise does not become sovereignty.
- [ ] Newcomer mobility possible.
- [ ] Evidence more portable than scores.

## Knowledge
- [ ] Storage ≠ memory.
- [ ] Artifact ≠ platform.
- [ ] Claim/source/validation distinct.
- [ ] Pluralism ≠ equal weight.
- [ ] Fiction declared context.
- [ ] Portable ≠ public.

## Semantics
- [ ] Same word not assumed same concept.
- [ ] Translation ≠ semantic interoperability.
- [ ] Non-equivalence representable.
- [ ] No hidden dominant semantic language.

## Judgment/attention
- [ ] Facts distinct from readings.
- [ ] Lenses do not rewrite participation facts.
- [ ] Defaults/rankings recognized as attention power.
- [ ] Popularity, visibility, urgency, importance distinct.
- [ ] Exploration/new entrants preserved.

## Authority/execution
- [ ] Advice distinct from decision authority.
- [ ] Decision rationale can be recorded.
- [ ] Experts and decision-makers evaluable against outcomes.
- [ ] Decision distinct from execution.
- [ ] Execution includes feedback/correction.

## Federation/resilience
- [ ] Replication precedes federation conceptually.
- [ ] Federation optional where intended.
- [ ] Technical forkability ≠ social legitimacy.
- [ ] Information, authority, execution can live at different scales.
- [ ] Selective permeability avoids total exposure/isolation.
- [ ] Offline claims scoped to truly local functions.

## AI
- [ ] Built with AI ≠ powered by AI.
- [ ] Deterministic canonical runtime described accurately.
- [ ] Optional AI output does not silently become canonical state.
- [ ] Older hybrid claims not imported as current truth.

## Cumulativity
- [ ] Output/outcome/learning/capability gain distinct.
- [ ] Failure can create future capacity.
- [ ] Success can consume future capacity.
- [ ] Documentation ≠ mastery.
- [ ] Independent reproduction beyond the founding group is practical; creator-owned channels are not incorrectly required to become founderless.

## Narrative
- [ ] Narrative = manifestation/orientation, not proof.
- [ ] Anti-cult/founder-decentering explicit.
- [ ] Narrative can be forked/rethemed.
- [ ] Salience ≠ evidence.
- [ ] Narrative memory points back to documentary memory.

## Measurement/falsification
- [ ] No magic coherence score.
- [ ] Metrics cover participation→knowledge→reuse→decision→action→outcome→learning.
- [ ] Costs/tradeoffs measured where possible.
- [ ] Major mechanisms have failure criteria.
- [ ] kOA can fail without definitional protection.
- [ ] Theory can be narrowed/rejected.

## Style
- [ ] Cohesive prose rather than listicle.
- [ ] Terms defined only when useful.
- [ ] Formulas have translation, meaning, status.
- [ ] Examples clearly not proof.
- [ ] kOA follows functions.
- [ ] Book invites scrutiny, not allegiance.

## Centrality / articulation hub
- [ ] Strong hub is represented as an intended design target where kOA is discussed.
- [ ] Replication/federation are not misdescribed as rejection of centrality.
- [ ] Polycentricity is compatible with multiple strong centers.
- [ ] Search/social superiority claims remain hypotheses unless benchmarked.
- [ ] Symbolic centrality is not converted into institutional sovereignty.

## Relational centrality and symbolic analogy

- [ ] Relational centrality is distinguished from sovereign authority.
- [ ] Any use of "communion" is clearly relational, not a requirement of religious belief.
- [ ] Any Christ analogy is explicitly marked interpretive and is never used as evidence, sacred legitimation or founder identification.
- [ ] The general principle remains intelligible with another symbol or no symbol.

## Cross-domain generalization

- [ ] Shared primitives do not erase domain-specific safety, legal, epistemic or authority constraints.
- [ ] Human–AI project-development history is not presented as independent validation.
- [ ] Cross-domain reuse claims expose failure criteria and counterexamples.
